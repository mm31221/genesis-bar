<?php
include("pag php/menu.php");

$categorias = categorias_menu();
?>

<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Genesis Bar</title>
	<link rel="stylesheet" href="css/estilo.css">
</head>
<body>
	<div class="contenedor">
		<h1>Genesis Bar</h1>
		<p>Sistema de comandas</p>

		<form action="pag php/pedido.php" method="post">
			<label for="nombre_cliente">Nombre del cliente</label>
			<input id="nombre_cliente" type="text" name="nombre_cliente" required>

			<label for="telefono_cliente">Telefono</label>
			<input id="telefono_cliente" type="tel" name="telefono_cliente" required>

			<label for="email_cliente">Mail</label>
			<input id="email_cliente" type="email" name="email_cliente">

			<label for="tipo_pedido">Tipo de pedido</label>
			<select id="tipo_pedido" name="tipo_pedido" required>
				<option value="delivery">Delivery</option>
				<option value="salon">Mesa en salon</option>
				<option value="take_away">Take away</option>
			</select>

			<label for="direccion">Direccion</label>
			<input id="direccion" type="text" name="direccion">

			<label for="mesa">Mesa</label>
			<input id="mesa" type="text" name="mesa">

			<label for="producto">Producto</label>
			<select id="producto" name="producto" required>
				<option value="">Seleccionar producto</option>
				<?php foreach ($categorias as $categoria => $productos): ?>
					<optgroup label="<?php echo htmlspecialchars($categoria); ?>">
						<?php foreach ($productos as $codigo => $producto): ?>
							<option
								value="<?php echo htmlspecialchars($codigo); ?>"
								data-precio="<?php echo htmlspecialchars($producto["precio"]); ?>"
								data-descripcion="<?php echo htmlspecialchars($producto["descripcion"]); ?>"
							>
								<?php echo htmlspecialchars($producto["nombre"]); ?> - $<?php echo number_format($producto["precio"], 0, ',', '.'); ?>
							</option>
						<?php endforeach; ?>
					</optgroup>
				<?php endforeach; ?>
			</select>

			<div class="detalle-producto" id="detalle_producto">Elegí un producto para ver el detalle.</div>

			<label for="cantidad">Cantidad</label>
			<input id="cantidad" type="number" name="cantidad" min="1" value="1" required>

			<div class="detalle-producto total-preview" id="total_preview">Total estimado: $0</div>

			<button type="submit">Registrar pedido</button>
		</form>

		<div class="acciones">
			<a href="index_cliente.php">Index de cliente</a>
			<a href="pag php/comandas.php">Ver todas las comandas</a>
			<a href="pag php/cocina.php">Pantalla de cocina</a>
		</div>
	</div>

	<script>
		const tipoPedido = document.getElementById("tipo_pedido");
		const direccion = document.getElementById("direccion");
		const mesa = document.getElementById("mesa");
		const producto = document.getElementById("producto");
		const cantidad = document.getElementById("cantidad");
		const detalleProducto = document.getElementById("detalle_producto");
		const totalPreview = document.getElementById("total_preview");

		function actualizarCamposPedido() {
			const esDelivery = tipoPedido.value === "delivery";
			const esSalon = tipoPedido.value === "salon";

			direccion.required = esDelivery;
			mesa.required = esSalon;
			direccion.disabled = !esDelivery;
			mesa.disabled = !esSalon;
		}

		function actualizarProducto() {
			const opcion = producto.options[producto.selectedIndex];
			const precio = Number(opcion.dataset.precio || 0);
			const unidades = Number(cantidad.value || 0);
			const descripcion = opcion.dataset.descripcion || "";

			detalleProducto.textContent = descripcion || "Elegí un producto para ver el detalle.";
			totalPreview.textContent = "Total estimado: $" + (precio * unidades).toLocaleString("es-AR");
		}

		tipoPedido.addEventListener("change", actualizarCamposPedido);
		producto.addEventListener("change", actualizarProducto);
		cantidad.addEventListener("input", actualizarProducto);

		actualizarCamposPedido();
		actualizarProducto();
	</script>
</body>
</html>
